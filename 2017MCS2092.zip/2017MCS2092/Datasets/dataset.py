import sklearn.datasets as sd
import matplotlib.pyplot as plt
import numpy as np
from sklearn import manifold, datasets

Moon, B = sd.make_moons(n_samples=20000, noise=0.06)
Circle, D = sd.make_circles(n_samples=20000, noise=0.05, factor=.3)
Blob_big,F  = sd.make_blobs(n_samples=10000, centers=1, cluster_std=1.3, center_box=(-4.0, 4.0),random_state =1)
Blob_small1,F=sd.make_blobs(n_samples=10000, centers=1, cluster_std=0.7, center_box=(-2, 2),random_state =1)
Blob_small2,F=sd.make_blobs(n_samples=10000, centers=1, cluster_std=0.4, center_box=(-3, 3),random_state =1)

X=np.random.uniform(low=-10, high=10, size=(3000))
Sin_Y=np.array([np.sin(i)+np.random.uniform(-0.2,0.2)  for i in X])
Cos_Y=np.array([np.cos(i)+np.random.uniform(-0.2,0.2)  for i in X])

S_mixed,F = datasets.samples_generator.make_s_curve(10000,0.1, random_state=0)
S_mixed[:,2]=[i+np.random.randint(2)  for i in S_mixed[:,2]]
S_mixed[:,0]=[i+np.random.randint(1)  for i in S_mixed[:,0]]
S_single, F = datasets.samples_generator.make_s_curve(10000,0.1, random_state=0)
S_blob1, F = sd.make_blobs(n_samples=2000, centers=1, cluster_std=0.08, center_box=(-2, 2),random_state =1)
S_blob2, F = sd.make_blobs(n_samples=2000, centers=1, cluster_std=0.08, center_box=(-2, 2),random_state =1)

out_file = open("dataset.txt", "w")
for i in Moon:    out_file.write(str(i[0]*3 + 8) + " " + str(i[1]*4 + 8) + "\n")
for i in Circle:    out_file.write(str(i[0]*8 - 7) + " " + str(i[1]*1.5 + 8) + "\n")  
    
for i in Blob_big:    out_file.write(str(i[0]*3.5 - 10) + " " + str(i[1]*1.5 - 10) + "\n")
for i in Blob_small1:    out_file.write(str(i[0]- 5) + " " + str(i[1] - 8) + "\n")
for i in Blob_small2:    out_file.write(str(i[0]-9) + " " + str(i[1]-5.5) + "\n")
    
for i in S_mixed:    out_file.write(str(i[0]*1.5 - 20) + " " + str(i[2]+8) + "\n") 
    
for i in S_single:    out_file.write(str(i[0]*3+9) + " " + str(i[2]*3-5) + "\n")    
for i in S_blob1:    out_file.write(str(i[0]*3 +10) + " " + str(i[1]*3-5) + "\n")
for i in S_blob2:    out_file.write(str(i[0]*3 + 10) + " " + str(i[1]*3-11) + "\n")  

for i in range(len(X)):    out_file.write(str(X[i]-15) + " " + str(Sin_Y[i]) + "\n") 
for i in range(len(X)):    out_file.write(str(X[i]-15) + " " + str(Cos_Y[i]+1.3) + "\n")  
    
out_file.close()

a=np.genfromtxt("dataset.txt")
plt.figure(figsize=[12,12])
plt.scatter(a[:,0],a[:,1])
plt.show()
